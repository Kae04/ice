<form method="get" class="searchform" action="">
  <input type="text" placeholder="キーワード検索!!" name="s" class="searchfield" />
  <input type="submit" value="" alt="検索" title="検索" class="searchsubmit" />
</form>